eval "$(conda shell.bash hook)"
conda activate crm_syd
python /home/jayesh/mgs_ai/crm_syd_1/crm_sydeny_main.py