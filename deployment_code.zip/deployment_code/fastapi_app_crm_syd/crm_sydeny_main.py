from CRM_SYD_main_app_2.classification.wrapper import process_file
from CRM_SYD_main_app_2.table_extract.wrapper import TEWrapper
from CRM_SYD_main_app_2.main_page_processing.process_core import mainPageProcess
from CRM_SYD_main_app_2.keyword_mapping.Keyword_Mapping_Core import KeywordMappingCore
from CRM_SYD_main_app_2.database.database import get_db1,get_db
from CRM_SYD_main_app_2.database import db_models
from CRM_SYD_main_app_2.data_dump_module.DataDump import DataDump
from glob import glob
import os
import logging
from logging.handlers import TimedRotatingFileHandler
from logging import FileHandler
from datetime import datetime,date

fname = date.today().strftime("%d_%m_%Y")+".log"
filename = os.path.join("/home/jayesh/mgs_ai/crm_syd_1/wrapper_logs/",fname)
logger = logging.getLogger('MasterLog')
logger.setLevel(logging.DEBUG)
handler = TimedRotatingFileHandler(filename,when='midnight',backupCount=3)
formatter = logging.Formatter(fmt=f'[%(asctime)] %(levelename)s %(message)s',datefmt="%Y-%m-%d %H:%M:%S%z")
logger.addHandler(handler)



def extract_data(pdf_file):
    logger.info(f"classification module start")
    fileid =  process_file(pdf_file)
    logger.info(f"classification module completed")
    logger.info(f"table extraction module start")
    TE_obj = TEWrapper()
    TE_obj.process_file(fileid=fileid)
    logger.info(f"table extraction module completed")
    logger.info(f"main page processing module start")
    mp = mainPageProcess()
    cbs_dict,cpl_dict,ccf_dict,meta_dict,final_notes_dict,ref_notes_list, notes_region_meta_data,cropped_table_dict = mp.process_main_pages(fileid=fileid)
    logger.info(f"main page processing module completed")
    logger.info(f"keywords mapping module start")
    kmp = KeywordMappingCore(cbs_dict=cbs_dict,cpl_dict=cpl_dict,ccf_dict=ccf_dict,notes_ref_dict=ref_notes_list,notes_region_meta_data=notes_region_meta_data,standardised_cropped_dict=mp.standardised_cropped_dict,standard_note_meta_dict=mp.standard_note_meta_dict,transformed_standardised_cropped_dict=mp.transformed_standardised_cropped_dict,month=mp.month)
    kmp.CBS_bucketing()
    kmp.CPL_bucketing()
    kmp.CCF_bucketing()
    logger.info(f"keywords mapping module completed")
    logger.info(f"data dump mapping module start")
    data_dump_obj = DataDump(fileid=fileid,meta_dict=mp.meta_dict,cbs_resposne_bucket=kmp.cbs_bucket_response_dict,cpl_resposne_bucket=kmp.cpl_bucket_response_dict,ccf_resposne_bucket=kmp.ccf_df_response_dict)
    data_dump_obj.trigger_job()
    logger.info(f"data dump mapping module completed")


def process_files(file_dir):
    files = glob(f'{file_dir}/*.pdf')
    print(files)
    for file in files:
        base_filename = os.path.basename(file).split('.')[0]
        extract_data(file)
        os.remove(file)


# def __main__():
if __name__ == "__main__":
    process_files('./CRM_SYD_input_files/')







