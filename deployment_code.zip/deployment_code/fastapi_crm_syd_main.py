import shutil
import pandas as pd
import uvicorn
from fastapi import FastAPI, UploadFile
from fastapi.responses import HTMLResponse
from starlette.responses import FileResponse
from PyPDF2 import PdfFileWriter, PdfFileReader
import glob
import os
import re
import glob
import shutil
from PyPDF2 import PdfFileWriter, PdfFileReader
import sys, errno  
from crm_sydeny_main import *
from signal import signal, SIGPIPE, SIG_DFL  
signal(SIGPIPE,SIG_DFL) 

app = FastAPI()


file_save_path = "/home/jayesh/mgs_ai/crm_syd_1/CRM_SYD_input_files"
shell_scipt = "/home/jayesh/mgs_ai/crm_syd_1/crm_batch_trigger.sh"
CDM_op_dir = "/home/jayesh/mgs_ai/crm_syd_1/CRM_SYD_main_app_2/CDM_Output"


@app.post("/", response_class=HTMLResponse)
async def read_items(file: UploadFile):
    # print(file.filename)
    with open(f"/home/jayesh/mgs_ai/crm_syd_1/fastapi_app_crm_syd/{file.filename}", "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # try:
    source = f"/home/jayesh/mgs_ai/crm_syd_1/fastapi_app_crm_syd/{file.filename}"
    destination = f"{file_save_path}/{file.filename}"
    shutil.copyfile(source,destination)

    # os.popen(f'sh /home/jayesh/mgs_ai/crm_syd_1/crm_batch_trigger.sh > fastapi.log')
    process_files("/home/jayesh/mgs_ai/crm_syd_1/CRM_SYD_input_files")
    file_basename = os.path.splitext(os.path.basename(file.filename))[0]
    print(file_basename)
    if os.path.exists(f"{CDM_op_dir}/{file_basename}.xlsx"):
        source_op = f"{CDM_op_dir}/{file_basename}.xlsx"  
        destination_op =  f"{file_basename}.xlsx"
        shutil.copyfile(source_op,destination_op)

    if os.path.exists(f"{file_basename}.xlsx"):
        # filename = str(file.filename).rsplit('.', 1)[0]
        headers = {'Content-Disposition': f'attachment; filename="{file_basename}.xlsx"'}
        return FileResponse(
            path=f"{file_basename}.xlsx",
            headers=headers
        )
    else:
        return "error occured or no tables found"

    # except IOError as e:
    #     if e.errno == errno.EPIPE:
    #         pass

    # shutil.rmtree(output_dir, ignore_errors=True)
    # os.makedirs(output_dir, exist_ok=True)
    # shutil.copy('./temp.pdf',f'{output_dir}/{input_file}') # TODO - Remove this line in testing
    # input_pdf = PdfFileReader(open(f'{output_dir}/{input_file}', "rb"),strict=False)
    # for i in range(input_pdf.numPages):
    #     output = PdfFileWriter()
    #     output.addPage(input_pdf.getPage(i))
    #     with open(f"{output_dir}/document-page-{i}.pdf", "wb") as outputStream:
    #         output.write(outputStream)
    # pdf_paths = glob.glob(f"{output_dir}/document-page-*.pdf")
    # pdf_paths.sort(key=lambda x:[int(c) if c.isdigit() else c for c in re.split(r'(\d+)', x)])
    # paged_dict = {}
    # # for index, pdf in enumerate(pdf_paths):
    # #     df = analyzer.analyze(path=pdf)
    # #     df.reset_state()
    # #     page = next(iter(df))
    # #     paged_dict[index] = {}
    # #     for tid, table in enumerate(page.tables):
    # #         try:
    # #             df_list = pd.read_html(table.html)
    # #             dfx = df_list[0]
    # #         # dfx.insert(0, reference_key_name, "")
    # #         # try:
    # #         #     notes_list = dfx[0].str.contains(match_word, case=False)
    # #         #     for _idx, notes in enumerate(notes_list):
    # #         #         if notes:
    # #         #             matches = re.findall(regex, str(dfx[0][_idx]))
    # #         #             dfx[reference_key_name][_idx] = matches
    # #         # except Exception as e:
    # #         #     print(e)
    # #         #     pass
    # #             paged_dict[index][tid] = dfx
    # #         except:
    # #             pass

    # if len(paged_dict)>0:
    #     print(len(paged_dict))
    #     writer = pd.ExcelWriter(file_save_path, engine='xlsxwriter')
    #     for k,v in paged_dict.items():
    #         #print(k)
    #         if len(paged_dict[k])>0:
    #             for p,q in paged_dict[k].items():
    #                 df1 = q
    #                 #print(df1)
    #                 df1.to_excel(writer, sheet_name=f"page{k}_table{p}",index=False)
    #     writer.save()
    
    # if os.path.exists(file_save_path):
    #     filename = str(file.filename).rsplit('.', 1)[0]
    #     headers = {'Content-Disposition': f'attachment; filename="{filename}.xlsx"'}
    #     return FileResponse(
    #         path=file_save_path,
    #         headers=headers
    #     )
    # else:
    #     return "error occured or no tables found"
if __name__ == '__main__':
    uvicorn.run(app, host='127.0.0.1', port=8000)
    print("running")
